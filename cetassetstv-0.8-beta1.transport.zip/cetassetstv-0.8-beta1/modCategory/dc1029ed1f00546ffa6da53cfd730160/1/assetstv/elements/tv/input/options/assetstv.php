<?php
/**
 * @package modx
 * @subpackage processors.element.tv.renders.mgr.inputproperties
 */
return $modx->smarty->fetch($modx->getOption('core_path').'components/assetstv/elements/tv/input/tpl/assetstvprops.tpl');