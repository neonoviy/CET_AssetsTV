<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'Part of Content Editor Tolls. Best with CET_TinyMCE or CET_CKEditor
Adds assetsTV input type for TVs, where you can upload files and insert them to Rich Text Editor. Shows already uploaded files in specified directories. Supports TinyMCE and CKEditor. 
You can output files with assetsTV snippet.
Author Denis Dyranov (Dyranov.ru)
Version: 0.8',
    'changelog' => 'Changelog for Content Editor Tools AssetsTV

0.8-beta1 (12.02.2016)
===========
- Integration with CET_Builder
- UI improvements

0.7-beta1 (03.01.2016)
===========
- Added Toggle view option
- Added ability to insert multiple files to RTE
- UI improvements
- Added tmb_max_height parameter to assetTV snippet to calculate sizes of thumbs
- Some bugs fixed

0.6-beta2 (28.11.2015)
===========
- Fixed bug in assetstv snippet

0.5-beta1 (27.11.2015)
===========
- Initial Version',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2170669f975f3cf7447d7fe2fbdffbcb',
      'native_key' => 'cetassetstv',
      'filename' => 'modNamespace/e87e3ea3d6ac8eff283af78110466b0e.vehicle',
      'namespace' => 'cetassetstv',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'f924963587bb7028181d1ff35a43b7b3',
      'native_key' => 16,
      'filename' => 'modPlugin/45f5b57f6c4d9902d705d90e3538702d.vehicle',
      'namespace' => 'cetassetstv',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8447ce7a6e163658e45af5d28fda0db0',
      'native_key' => 1,
      'filename' => 'modCategory/dc1029ed1f00546ffa6da53cfd730160.vehicle',
      'namespace' => 'cetassetstv',
    ),
  ),
);